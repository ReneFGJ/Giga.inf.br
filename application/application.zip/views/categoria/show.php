<div class="container">
	<div class="row">
		<div class="col-md-12"><span class="small">Categoria</span><br><span class="superbig"><?php echo $pc_nome;?></span></div>
	</div>
</div>

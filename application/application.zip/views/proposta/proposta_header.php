<div class="container">
	<div class="row">
		<div class="col-md-3"><span class="small">Proposta nº</span><br><span class="big"><?php echo $pp_nr;?>/<?php echo $pp_ano;?></span></div>
		<div class="col-md-3"><span class="small">Data</span><br><span class="big"><?php echo stodbr($pp_data);?></span></div>
		<div class="col-md-6"><span class="small">Vendedor</span><br><span class="big"><?php echo $us_nome;?></span></div>
	</div>
</div>
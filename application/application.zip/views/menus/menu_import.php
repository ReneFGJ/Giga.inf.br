<ul>
	<li><a href="<?php echo base_url('index.php/import/cpagar/');?>">Contas a pagar</a></li>
	<li><a href="<?php echo base_url('index.php/import/usuarios/');?>">Usuários</a></li>
	<li><a href="<?php echo base_url('index.php/import/fornecedores/');?>">Fornecedores</a></li>
</ul>
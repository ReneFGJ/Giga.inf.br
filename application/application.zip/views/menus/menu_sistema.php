<div class="row">
	<div class="col-md-4">
		<img src="<?php echo base_url('');?>" class="">
		<
	</div>
</div>

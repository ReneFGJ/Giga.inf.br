<div class="container">
<?php
echo anchor(base_url('index.php'),'Home',array('onclick'=>'confirmar();','title' => 'Home'));
?>
</div>
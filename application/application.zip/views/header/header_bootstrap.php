	<!-- Bootsratp -->
		<!-- CSS -->
		<link rel="stylesheet" href="<?php echo base_url('css/bootstrap.css');?>">

		<!-- JS -->
		<script src="<?php echo base_url('js/bootstrap.min.js');?>"></script>
